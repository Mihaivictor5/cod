package org.firstinspires.ftc.teamcode.ftc16072;

import org.firstinspires.ftc.robotcore.external.Telemetry;

abstract class QQ_AutoAction {
    abstract boolean run(Robot robot, double gameTime, Telemetry telemetry);
}
