package virtual_robot.controller;

public class Wall{
}
