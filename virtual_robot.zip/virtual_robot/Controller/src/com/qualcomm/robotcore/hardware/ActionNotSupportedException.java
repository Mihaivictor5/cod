package com.qualcomm.robotcore.hardware;

public class ActionNotSupportedException extends RuntimeException {

    public ActionNotSupportedException() { super(); }

    public ActionNotSupportedException(String msg) { super(msg); }

}
